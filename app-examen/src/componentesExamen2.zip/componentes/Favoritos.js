import React from 'react'

export default function Favoritos() {
    return (
        <div>
            <div>
                <h1>Consejo favoritos</h1>
            </div>
            
            <div>
                <strong>advice:</strong> {todos.slip.advice}
            </div>
            <div>
                <button>Quitar de la lista</button>

            </div>

        </div>
    )
}
