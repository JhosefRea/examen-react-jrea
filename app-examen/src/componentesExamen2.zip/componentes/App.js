import Advices from "./Advices";
import Buscador from "./Buscador";

const onSubmit = (input) => ({ 
  text: input
})

function App() {
  return (
    <>
      <Advices />
      <Buscador onSubmit={onSubmit}/>
      
    </>
  );
}

export default App;
